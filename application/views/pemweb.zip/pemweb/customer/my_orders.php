<center><!--  center Begin  -->
    
    <h1> My Orders </h1>
    
    <p class="lead"> Your orders on one place</p>
    
    <p class="text-muted">
        
        If you have any questions, feel free to <a href="../contact.php">Contact Us</a>. Our Customer Service work 24/7
        
    </p>
    
</center><!--  center Finish  -->


<hr>


<div class="table-responsive"><!--  table-responsive Begin  -->
    
    <table class="table table-bordered table-hover"><!--  table table-bordered table-hover Begin  -->
        
        <thead><!--  thead Begin  -->
            
            <tr><!--  tr Begin  -->
                
                <th> No: </th>
                <th> Due Amount: </th>
                <th> Invoice No: </th>
                <th> Qty: </th>
                <th> Size: </th>
                <th> Order Date:</th>
                <th> Paid / Unpaid: </th>
                <th> Status: </th>
                
            </tr><!--  tr Finish  -->
            
        </thead><!--  thead Finish  -->
        
        <tbody><!--  tbody Begin  -->
            
            <tr><!--  tr Begin  -->
                
                <th> #1 </th>
                
                <td> Rp299.000,- </td>
                <td> 00013612 </td>
                <td> 1 </td>
                <td> Large </td>
                <td> 25-05-2020 </td>
                <td> Unpaid </td>
                
                <td>
                    
                    <a href="confirm.php" target="_blank" class="btn btn-primary btn-sm"> Confirm Paid </a>
                    
                </td>
                
            </tr><!--  tr Finish  -->
            
            <tr><!--  tr Begin  -->
                
                <th> #2 </th>
                
                <td> Rp1.299.000,- </td>
                <td> 00013889 </td>
                <td> 1 </td>
                <td> Medium </td>
                <td> 25-05-2020 </td>
                <td> Unpaid </td>
                
                <td>
                    
                    <a href="confirm.php" target="_blank" class="btn btn-primary btn-sm"> Confirm Paid </a>
                    
                </td>
                
            </tr><!--  tr Finish  -->
            
            <tr><!--  tr Begin  -->
                
                <th> #3 </th>
                
                <td> Rp21.999.000,- </td>
                <td> 00013666 </td>
                <td> 1 </td>
                <td> 6 </td>
                <td> 25-05-2020 </td>
                <td> Unpaid </td>
                
                <td>
                    
                    <a href="confirm.php" target="_blank" class="btn btn-primary btn-sm"> Confirm Paid </a>
                    
                </td>
                
            </tr><!--  tr Finish  -->
            
        </tbody><!--  tbody Finish  -->
        
    </table><!--  table table-bordered table-hover Finish  -->
    
</div><!--  table-responsive Finish  -->